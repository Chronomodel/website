#include "GraphZone.h"


GraphZone::GraphZone():
mXStart(0),
mXEnd(0),
mColor(Qt::black)
{
    
}

GraphZone::~GraphZone()
{
    
}
