#include "MCMCView.h"
#include <QtWidgets>


MCMCView::MCMCView(QWidget* parent, Qt::WindowFlags flags):QWidget(parent, flags)
{
    
}

MCMCView::~MCMCView()
{
    
}
