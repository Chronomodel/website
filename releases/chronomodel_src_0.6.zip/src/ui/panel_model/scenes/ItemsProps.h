#ifndef ItemsProps_H
#define ItemsProps_H

#define ITEM_BORDER 1.f
#define ITEM_TITLE_H 20.f
#define ITEM_PHASES_H 10.f
#define ITEM_DATE_M 3.f
#define ITEM_DATE_W 15.f
#define ITEM_DATE_H 15.f

#endif